<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Gutta</name>
    <message>
        <location filename="BusConfigDlg.cpp" line="34"/>
        <location filename="BusConfigDlg.cpp" line="41"/>
        <location filename="BusConfigDlg.cpp" line="95"/>
        <source>$CommandPort:</source>
        <translation>Command Port:</translation>
    </message>
    <message>
        <location filename="BusConfigDlg.cpp" line="34"/>
        <location filename="BusConfigDlg.cpp" line="49"/>
        <source>$PleaseInputNumber</source>
        <translation>Please input number</translation>
    </message>
    <message>
        <location filename="BusConfigDlg.cpp" line="41"/>
        <location filename="BusConfigDlg.cpp" line="56"/>
        <source>$InputNumberOutOfRange</source>
        <translation>Input number out of range</translation>
    </message>
    <message>
        <location filename="BusConfigDlg.cpp" line="49"/>
        <location filename="BusConfigDlg.cpp" line="56"/>
        <location filename="BusConfigDlg.cpp" line="96"/>
        <source>$MonitorPort:</source>
        <translation>Monitor Port:</translation>
    </message>
    <message>
        <location filename="BusConfigDlg.cpp" line="94"/>
        <source>$IPAddress:</source>
        <oldsource>$IPAddress</oldsource>
        <translation>IP Address:</translation>
    </message>
    <message>
        <location filename="BusConfigDlg.cpp" line="97"/>
        <source>$Defaults</source>
        <translation>Defaults</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="112"/>
        <source>$ServiceEntryUnknown:</source>
        <translation>Service Entry Unknown:</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="124"/>
        <source>$HostEntryUnknown:</source>
        <translation>Host Entry Unknown:</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="132"/>
        <source>$ProtocolEntryUnknown:</source>
        <oldsource>$ProtocolEntryUnkown:</oldsource>
        <translation>Protocol Entry Unknown:</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="139"/>
        <source>$CreateSocketFailed:</source>
        <translation>Create Socket Failed:</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="145"/>
        <source>$ConnectSocketFailed:</source>
        <translation>Connect Socket Failed:</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="155"/>
        <source>$BusAlreadyOpened</source>
        <translation>Bus Already Opened</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="159"/>
        <source>$WSAStartupError</source>
        <translation>WSA Startup Error</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="213"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="234"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="304"/>
        <source>$BusNotOpened</source>
        <translation>Bus Not Opened</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="217"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="238"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="308"/>
        <source>$ChannelNotExist</source>
        <translation>Channel Not Exist</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="222"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="313"/>
        <source>$WriteDataEmpty</source>
        <translation>Write Data Empty</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="226"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="317"/>
        <source>$SendDataFailed</source>
        <translation>Send Data Failed</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="252"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="256"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="331"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="335"/>
        <source>$WaitingDataFailed</source>
        <translation>Waiting Data Failed</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="262"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="341"/>
        <source>$ReadDataFailed</source>
        <translation>Read Data Failed</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="293"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="372"/>
        <source>$ReceiveDataTimeout</source>
        <translation>Receive Data Timeout</translation>
    </message>
</context>
</TS>
