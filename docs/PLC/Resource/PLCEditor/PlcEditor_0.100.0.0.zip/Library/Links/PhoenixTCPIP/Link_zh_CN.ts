<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Gutta</name>
    <message>
        <location filename="BusConfigDlg.cpp" line="34"/>
        <location filename="BusConfigDlg.cpp" line="41"/>
        <location filename="BusConfigDlg.cpp" line="95"/>
        <source>$CommandPort:</source>
        <translation>通讯端口:</translation>
    </message>
    <message>
        <location filename="BusConfigDlg.cpp" line="34"/>
        <location filename="BusConfigDlg.cpp" line="49"/>
        <source>$PleaseInputNumber</source>
        <translation>请输入数字</translation>
    </message>
    <message>
        <location filename="BusConfigDlg.cpp" line="41"/>
        <location filename="BusConfigDlg.cpp" line="56"/>
        <source>$InputNumberOutOfRange</source>
        <translation>输入的数字超出范围</translation>
    </message>
    <message>
        <location filename="BusConfigDlg.cpp" line="49"/>
        <location filename="BusConfigDlg.cpp" line="56"/>
        <location filename="BusConfigDlg.cpp" line="96"/>
        <source>$MonitorPort:</source>
        <translation>监控端口:</translation>
    </message>
    <message>
        <location filename="BusConfigDlg.cpp" line="94"/>
        <source>$IPAddress:</source>
        <oldsource>$IPAddress</oldsource>
        <translation>IP地址:</translation>
    </message>
    <message>
        <location filename="BusConfigDlg.cpp" line="97"/>
        <source>$Defaults</source>
        <translation>默认值</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="112"/>
        <source>$ServiceEntryUnknown:</source>
        <translation>服务节点未知:</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="124"/>
        <source>$HostEntryUnknown:</source>
        <translation>主机节点未知:</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="132"/>
        <source>$ProtocolEntryUnknown:</source>
        <oldsource>$ProtocolEntryUnkown:</oldsource>
        <translation>协议节点未知:</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="139"/>
        <source>$CreateSocketFailed:</source>
        <translation>创建嵌套子失败:</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="145"/>
        <source>$ConnectSocketFailed:</source>
        <translation>连接嵌套字失败:</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="155"/>
        <source>$BusAlreadyOpened</source>
        <translation>总线已经被打开</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="159"/>
        <source>$WSAStartupError</source>
        <translation>WSA启动错误</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="213"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="234"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="304"/>
        <source>$BusNotOpened</source>
        <translation>总线没有被打开</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="217"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="238"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="308"/>
        <source>$ChannelNotExist</source>
        <translation>通道不存在</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="222"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="313"/>
        <source>$WriteDataEmpty</source>
        <translation>写入数据不能为空</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="226"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="317"/>
        <source>$SendDataFailed</source>
        <translation>发送数据失败</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="252"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="256"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="331"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="335"/>
        <source>$WaitingDataFailed</source>
        <translation>等待数据失败</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="262"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="341"/>
        <source>$ReadDataFailed</source>
        <translation>读取数据失败</translation>
    </message>
    <message>
        <location filename="Link/GuttaLibraryLink.cpp" line="293"/>
        <location filename="Link/GuttaLibraryLink.cpp" line="372"/>
        <source>$ReceiveDataTimeout</source>
        <translation>接收数据超时</translation>
    </message>
</context>
</TS>
