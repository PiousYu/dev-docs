<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>D00</name>
    <message>
        <location filename="MainFrm.cpp" line="264"/>
        <source>$File</source>
        <translation>&amp;File</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="265"/>
        <source>$Edit</source>
        <translation>&amp;Edit</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="266"/>
        <source>$View</source>
        <translation>&amp;View</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="267"/>
        <source>$PLC</source>
        <translation>&amp;PLC</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="251"/>
        <location filename="MainFrm.cpp" line="268"/>
        <location filename="MainFrm.cpp" line="442"/>
        <location filename="MainFrm.cpp" line="1960"/>
        <source>$Debug</source>
        <translation>&amp;Debug</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="269"/>
        <source>$Help</source>
        <translation>&amp;Help</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="250"/>
        <location filename="MainFrm.cpp" line="441"/>
        <location filename="MainFrm.cpp" line="1959"/>
        <source>$Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="252"/>
        <location filename="MainFrm.cpp" line="443"/>
        <location filename="MainFrm.cpp" line="1961"/>
        <source>$Instruction</source>
        <translation>Instruction</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="254"/>
        <location filename="MainFrm.cpp" line="428"/>
        <location filename="MainFrm.cpp" line="2056"/>
        <source>$ProjectManager</source>
        <translation>Project Manager</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="255"/>
        <location filename="MainFrm.cpp" line="429"/>
        <location filename="MainFrm.cpp" line="2057"/>
        <source>$SystemSymbols</source>
        <translation>System Symbols</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="256"/>
        <location filename="MainFrm.cpp" line="430"/>
        <location filename="MainFrm.cpp" line="2058"/>
        <source>$Instructions</source>
        <translation>Instructions</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="257"/>
        <location filename="MainFrm.cpp" line="431"/>
        <location filename="MainFrm.cpp" line="2059"/>
        <source>$GlobalVariable</source>
        <translation>Global Variables</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="258"/>
        <location filename="MainFrm.cpp" line="433"/>
        <location filename="MainFrm.cpp" line="2060"/>
        <source>$RelativeVariable</source>
        <translation>Relative Variable</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="259"/>
        <location filename="MainFrm.cpp" line="434"/>
        <location filename="MainFrm.cpp" line="2061"/>
        <source>$StatusChart</source>
        <translation>Status Chart</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="401"/>
        <source>$FileNew</source>
        <translation>&amp;New</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="402"/>
        <source>$FileOpen</source>
        <translation>&amp;Open...</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="403"/>
        <source>$RecentFiles</source>
        <translation>Recent Files</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="404"/>
        <source>$Save</source>
        <oldsource>Save</oldsource>
        <translation>&amp;Save...</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="405"/>
        <source>$SaveAs</source>
        <oldsource>SaveAs</oldsource>
        <translation>Save &amp;As...</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="406"/>
        <source>$ImportSymbols</source>
        <translation>I&amp;mport Symbols...</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="407"/>
        <source>$ExportSymbols</source>
        <translation>Expor&amp;t Symbols...</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="408"/>
        <source>$ImportTC6XML</source>
        <translation>&amp;Import TC6XML...</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="409"/>
        <source>$ExportTC6XML</source>
        <translation>&amp;Export TC6XML...</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="410"/>
        <source>$Print</source>
        <translation>&amp;Print...</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="411"/>
        <source>$PrintPreview</source>
        <translation>Print Preview</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="412"/>
        <source>$Exit</source>
        <translation>E&amp;xit</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="417"/>
        <source>$Undo</source>
        <translation>&amp;Undo</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="418"/>
        <source>$Redo</source>
        <translation>&amp;Redo</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="419"/>
        <source>$Cut</source>
        <translation>Cu&amp;t</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="420"/>
        <source>$Copy</source>
        <translation>&amp;Copy</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="421"/>
        <source>$Paste</source>
        <translation>&amp;Paste</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="422"/>
        <source>$SelectAll</source>
        <translation>Select &amp;All</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="423"/>
        <source>$FindAndReplace</source>
        <translation>&amp;Find and Replace...</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="432"/>
        <location filename="MainFrm.cpp" line="1467"/>
        <source>$ProgramBlock</source>
        <translation>Program Block</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="448"/>
        <source>$Arrange</source>
        <translation>&amp;Arrange</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="455"/>
        <source>$BuildConfiguration</source>
        <translation>Build Configuration</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="1066"/>
        <location filename="MainFrm.cpp" line="1090"/>
        <source>$SaveChangeAsk</source>
        <translation>Do you want to save the changes to your project?</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="1491"/>
        <source>$CorssReference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="1718"/>
        <source>$ExitToChangeOption</source>
        <translation>PLC Editor will now exit in order to change options.</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="261"/>
        <location filename="MainFrm.cpp" line="435"/>
        <location filename="MainFrm.cpp" line="2062"/>
        <source>$MessageOutput</source>
        <translation>Message Output</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="436"/>
        <source>$Toolbars</source>
        <translation>&amp;Toolbars</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="437"/>
        <source>$ApplicationLook</source>
        <translation>&amp;Application Look</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="449"/>
        <source>$Build</source>
        <translation>&amp;Build</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="450"/>
        <source>$Upload</source>
        <translation>&amp;Upload</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="451"/>
        <source>$Download</source>
        <translation>&amp;Download</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="452"/>
        <source>$Clear</source>
        <translation>&amp;Clear</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="453"/>
        <source>$Run</source>
        <translation>&amp;Run</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="454"/>
        <source>$Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="460"/>
        <source>$Connect</source>
        <translation>&amp;Connect</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="461"/>
        <source>$Disconnect</source>
        <translation>&amp;Disconnect</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="462"/>
        <source>$MonitorON</source>
        <translation>&amp;Monitor ON</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="463"/>
        <source>$MonitorOFF</source>
        <translation>Monitor &amp;OFF</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="468"/>
        <source>$Aboud</source>
        <translation>&amp;About...</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="469"/>
        <source>$SelectLanguage</source>
        <translation>&amp;Select Language</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="473"/>
        <source>$en_US</source>
        <translation>&amp;English (en_US)</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="474"/>
        <source>$zh_CN</source>
        <translation>&amp;Chinese (zh_CN)</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="263"/>
        <source>$Menu</source>
        <translation>Main Menu</translation>
    </message>
</context>
<context>
    <name>D01</name>
    <message>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="72"/>
        <source>$Project</source>
        <translation>Project</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="76"/>
        <source>$ProgramBlock</source>
        <translation>Program Block</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="77"/>
        <location filename="MainFrm.cpp" line="492"/>
        <source>$StatusChart</source>
        <translation>Status Chart</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="78"/>
        <source>$CrossReference</source>
        <translation>Cross Reference</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="79"/>
        <source>$Communication</source>
        <translation>Communication</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="534"/>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="549"/>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="564"/>
        <source>$InputSymbol:</source>
        <translation>Input Symbol:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="588"/>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="602"/>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="616"/>
        <source>$InputAddress:</source>
        <translation>Input Address:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="639"/>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="652"/>
        <location filename="GuttaLad/Frame/ProjectManagerFrm.cpp" line="665"/>
        <source>$InputComment:</source>
        <translation>Input Comment:</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="479"/>
        <source>$Open</source>
        <translation>Open</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="480"/>
        <source>$EditSymbol</source>
        <translation>Edit Symbol</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="481"/>
        <source>$EditAddress</source>
        <translation>Edit Address</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="482"/>
        <source>$EditComment</source>
        <translation>Edit Comment</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="483"/>
        <source>$Insert</source>
        <translation>Insert</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="484"/>
        <source>$Delete</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="485"/>
        <source>$Property</source>
        <translation>Property</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="489"/>
        <source>$GlobalVariable</source>
        <translation>Global Variables</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="490"/>
        <source>$Module</source>
        <translation>Module</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="491"/>
        <source>$FunctionBlock</source>
        <translation>Function Block</translation>
    </message>
</context>
<context>
    <name>D03</name>
    <message>
        <location filename="GuttaLad/Frame/InstructionsFrm.cpp" line="83"/>
        <source>$CoreSystem</source>
        <translation>Core System</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/InstructionsFrm.cpp" line="90"/>
        <source>$Subroutine</source>
        <translation>Subroutine</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/InstructionsFrm.cpp" line="97"/>
        <source>$FunctionBlock</source>
        <translation>Function Block</translation>
    </message>
</context>
<context>
    <name>D04</name>
    <message>
        <location filename="GuttaLad/Frame/GlobalVariableFrm.cpp" line="391"/>
        <source>$Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/GlobalVariableFrm.cpp" line="395"/>
        <source>$Usage</source>
        <translation>Usage</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/GlobalVariableFrm.cpp" line="399"/>
        <source>$Type</source>
        <translation>Data Type</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/GlobalVariableFrm.cpp" line="403"/>
        <source>$Init</source>
        <translation>Initial Value</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/GlobalVariableFrm.cpp" line="407"/>
        <source>$Comment</source>
        <translation>Comment</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="497"/>
        <source>$Cut</source>
        <translation>Cut</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="498"/>
        <source>$Copy</source>
        <translation>Copy</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="499"/>
        <source>$Paste</source>
        <translation>Paste</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="500"/>
        <source>$SelectAll</source>
        <translation>Select All</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="501"/>
        <source>$MoveUp</source>
        <translation>Move Up</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="502"/>
        <source>$MoveDown</source>
        <translation>Move Down</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="503"/>
        <source>$InsertRow</source>
        <translation>Insert Row</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="504"/>
        <source>$DeleteRow</source>
        <translation>Delete Row</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="505"/>
        <source>$InsertTable</source>
        <translation>Insert Table</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="506"/>
        <source>$DeleteTable</source>
        <translation>Delete Table</translation>
    </message>
</context>
<context>
    <name>D06</name>
    <message>
        <location filename="GuttaLad/Frame/RelativeVariableFrm.cpp" line="366"/>
        <source>$Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/RelativeVariableFrm.cpp" line="370"/>
        <source>$Usage</source>
        <translation>Usage</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/RelativeVariableFrm.cpp" line="374"/>
        <source>$Type</source>
        <translation>Data Type</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/RelativeVariableFrm.cpp" line="378"/>
        <source>$Init</source>
        <translation>Initial Value</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/RelativeVariableFrm.cpp" line="382"/>
        <source>$Comment</source>
        <translation>Comment</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="511"/>
        <source>$Cut</source>
        <translation>Cut</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="512"/>
        <source>$Copy</source>
        <translation>Copy</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="513"/>
        <source>$Paste</source>
        <translation>Paste</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="514"/>
        <source>$SelectAll</source>
        <translation>Select All</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="515"/>
        <source>$MoveUp</source>
        <translation>Move Up</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="516"/>
        <source>$MoveDown</source>
        <translation>Move Down</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="517"/>
        <source>$InsertRow</source>
        <translation>Insert Row</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="518"/>
        <source>$DeleteRow</source>
        <translation>Delete Row</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="519"/>
        <source>$InsertModule</source>
        <oldsource>$InsertTable</oldsource>
        <translation>Insert Module</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="520"/>
        <source>$InsertFunctionBlock</source>
        <translation>Insert Function Block</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="521"/>
        <source>$DeleteTable</source>
        <translation>Delete Table</translation>
    </message>
</context>
<context>
    <name>D07</name>
    <message>
        <location filename="GuttaLad/Frame/StatusChartFrm.cpp" line="313"/>
        <source>$Variable</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/StatusChartFrm.cpp" line="317"/>
        <source>$Value</source>
        <translation>Value</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="526"/>
        <source>$Cut</source>
        <translation>Cu&amp;t</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="527"/>
        <source>$Copy</source>
        <translation>&amp;Copy</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="528"/>
        <source>$Paste</source>
        <translation>&amp;Paste</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="529"/>
        <source>$SelectAll</source>
        <translation>Select &amp;All</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="530"/>
        <source>$MoveUp</source>
        <translation>Move Up</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="531"/>
        <source>$MoveDown</source>
        <translation>Move Down</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="532"/>
        <source>$InsertTable</source>
        <translation>Insert Table</translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="533"/>
        <source>$DeleteTable</source>
        <translation>Delete Table</translation>
    </message>
</context>
<context>
    <name>D08</name>
    <message>
        <location filename="GuttaLad/Frame/CrossReferFrm.cpp" line="280"/>
        <source>$Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/CrossReferFrm.cpp" line="284"/>
        <location filename="MainFrm.cpp" line="539"/>
        <source>$Location</source>
        <translation type="unfinished">Location</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/CrossReferFrm.cpp" line="288"/>
        <source>$Context</source>
        <translation type="unfinished">Context</translation>
    </message>
    <message>
        <location filename="GuttaLad/Frame/CrossReferFrm.cpp" line="512"/>
        <source>$Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="538"/>
        <source>$Refresh</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>D10</name>
    <message>
        <location filename="GuttaLad/Dialog/LinkConfigDlg.cpp" line="30"/>
        <source>$IndexNotExist:</source>
        <translation>Index Not Exist:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/LinkConfigDlg.cpp" line="48"/>
        <location filename="GuttaLad/Dialog/LinkConfigDlg.cpp" line="189"/>
        <source>$GetBusParamError:</source>
        <translation>Get Bus Param Error:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/LinkConfigDlg.cpp" line="60"/>
        <source>$LoadLibraryError:</source>
        <translation>Load Library Error:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/LinkConfigDlg.cpp" line="84"/>
        <source>$LinkConfiguration</source>
        <translation>Link Configuration</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/LinkConfigDlg.cpp" line="85"/>
        <source>$OK</source>
        <translation>OK2</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/LinkConfigDlg.cpp" line="86"/>
        <source>$Cancel</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>D41</name>
    <message>
        <location filename="GuttaLad/Dialog/TC6EditLadInstructionDlg.cpp" line="290"/>
        <source>$Catalog</source>
        <translation>Catalog</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6EditLadInstructionDlg.cpp" line="291"/>
        <source>$Index</source>
        <translation>Index</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6EditLadInstructionDlg.cpp" line="284"/>
        <source>$InputInstruction</source>
        <oldsource>$InputInstruction:</oldsource>
        <translation>Input Instruction</translation>
    </message>
</context>
<context>
    <name>D42</name>
    <message>
        <location filename="GuttaLad/Dialog/TC6EditLadOperandDlg.cpp" line="260"/>
        <source>$InputOperand</source>
        <translation>Input Operand</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6EditLadOperandDlg.cpp" line="266"/>
        <source>$Catalog</source>
        <translation>Catalog</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6EditLadOperandDlg.cpp" line="267"/>
        <source>$Index</source>
        <translation>Index</translation>
    </message>
</context>
<context>
    <name>D43</name>
    <message>
        <location filename="GuttaLad/Dialog/TC6EditLadInputDlg.cpp" line="312"/>
        <source>$InputUnit</source>
        <translation>Input Unit</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6EditLadInputDlg.cpp" line="313"/>
        <source>$Instruction</source>
        <translation>Instruction</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6EditLadInputDlg.cpp" line="314"/>
        <source>$Operand</source>
        <translation>Operand</translation>
    </message>
</context>
<context>
    <name>D44</name>
    <message>
        <location filename="GuttaLad/Dialog/TC6NetworkPropertyDlg.cpp" line="47"/>
        <source>$NetworkProperty</source>
        <translation>Network Property</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6NetworkPropertyDlg.cpp" line="48"/>
        <source>$Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6NetworkPropertyDlg.cpp" line="49"/>
        <source>$Comment</source>
        <translation>Comment</translation>
    </message>
</context>
<context>
    <name>D45</name>
    <message>
        <location filename="GuttaLad/Dialog/TC6SubroutinePropertyDlg.cpp" line="56"/>
        <source>$SubroutineProperty</source>
        <translation>Subroutine Property</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6SubroutinePropertyDlg.cpp" line="57"/>
        <source>$Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6SubroutinePropertyDlg.cpp" line="58"/>
        <source>$Comment</source>
        <translation>Comment</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6SubroutinePropertyDlg.cpp" line="59"/>
        <source>$Event</source>
        <translation>Event</translation>
    </message>
</context>
<context>
    <name>D46</name>
    <message>
        <location filename="GuttaLad/Dialog/TC6BuildConfigDlg.cpp" line="82"/>
        <source>$BuildConfiguration</source>
        <translation>Build Configuration</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6BuildConfigDlg.cpp" line="83"/>
        <source>$Defaults</source>
        <translation>Defaults</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6BuildConfigDlg.cpp" line="84"/>
        <source>$CompilerFileName:</source>
        <oldsource>$CompilerFileName</oldsource>
        <translation>Compiler File Name:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6BuildConfigDlg.cpp" line="85"/>
        <source>$CompileOption:</source>
        <translation>Compile Option:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6BuildConfigDlg.cpp" line="86"/>
        <source>$OutputDirectory:</source>
        <translation>Output Directory:</translation>
    </message>
</context>
<context>
    <name>D47</name>
    <message>
        <location filename="GuttaLad/Dialog/TC6FunctionBlockPropertyDlg.cpp" line="45"/>
        <source>$FunctionBlockProperty</source>
        <translation>Function Block Property</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6FunctionBlockPropertyDlg.cpp" line="46"/>
        <source>$Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6FunctionBlockPropertyDlg.cpp" line="47"/>
        <source>$Comment</source>
        <translation>Comment</translation>
    </message>
</context>
<context>
    <name>D48</name>
    <message>
        <location filename="GuttaLad/Dialog/TC6ModulePropertyDlg.cpp" line="45"/>
        <source>$ModuleProperty</source>
        <translation>Module Property</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6ModulePropertyDlg.cpp" line="46"/>
        <source>$Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/TC6ModulePropertyDlg.cpp" line="47"/>
        <source>$Comment</source>
        <translation>Comment</translation>
    </message>
</context>
<context>
    <name>D49</name>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="152"/>
        <source>$FindAndReplace</source>
        <translation>Find And Replace</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="153"/>
        <source>$FindWhat</source>
        <translation>Find What:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="154"/>
        <source>$ReplaceWith</source>
        <translation>Replace With:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="155"/>
        <source>$FindUp</source>
        <translation>Find Up</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="156"/>
        <source>$FindDown</source>
        <translation>Find Down</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="157"/>
        <source>$Next</source>
        <translation>Next</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="158"/>
        <source>$Replace</source>
        <translation>Replace</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="159"/>
        <source>$ReplaceAll</source>
        <translation>Replace All</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="168"/>
        <source>$Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="172"/>
        <source>$Location</source>
        <translation>Location</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="176"/>
        <source>$Context</source>
        <translation>Context</translation>
    </message>
</context>
<context>
    <name>Gutta</name>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaAddressManager.cpp" line="1124"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaAddressManager.cpp" line="1247"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaAddressManager.cpp" line="1305"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaAddressManager.cpp" line="1456"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaAddressManager.cpp" line="1655"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="242"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="249"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="274"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="331"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataSet.h" line="123"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataSet.h" line="132"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="170"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="240"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="262"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="279"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="296"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="304"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="312"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="380"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="396"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="413"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="429"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="434"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="441"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="506"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="523"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="540"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="556"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="561"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="717"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="832"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="855"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="869"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="895"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="921"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="958"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="968"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="978"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="994"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1004"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1020"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1031"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1082"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1107"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1121"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1149"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1165"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1175"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1191"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="169"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="274"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="297"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="316"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="334"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="398"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="417"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="431"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="474"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="479"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="487"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="560"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="577"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="596"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="613"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="651"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="667"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="684"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="699"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="704"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="711"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="781"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="799"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="818"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="835"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="872"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="889"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="906"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="921"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="926"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1141"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1256"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1279"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1293"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1319"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1345"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1382"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1392"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1402"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1418"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1428"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1444"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1462"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1513"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1538"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1557"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1585"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1601"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1611"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1627"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1665"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1755"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1783"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1833"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1836"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1893"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1896"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1911"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1933"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1962"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2014"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2066"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2100"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2119"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2133"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2146"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2168"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2190"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2249"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2298"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2318"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2372"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2375"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2391"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2401"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2411"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2420"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2429"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2477"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2538"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2547"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2556"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2571"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2588"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2607"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2611"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2626"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2662"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2672"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2686"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2711"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2742"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2757"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2772"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2787"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2814"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2836"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2889"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2901"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2926"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2947"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2972"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2993"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3019"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3042"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3069"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3093"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3118"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3134"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3168"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3187"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3232"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3251"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3275"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3299"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3320"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3339"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3358"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3382"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3403"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3427"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3448"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3472"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3493"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3533"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3554"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3578"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3599"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3623"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3644"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3668"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3689"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3713"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3734"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3762"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3771"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3780"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3789"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3798"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3817"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3836"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3874"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3919"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3959"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4044"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4065"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4083"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4103"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4118"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4126"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4129"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4142"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4153"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4166"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4179"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4192"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="4205"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="110"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="173"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="186"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="197"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="263"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="278"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="288"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="352"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="367"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="556"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="567"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="578"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="588"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="605"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="616"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="627"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditCom.cpp" line="686"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditCom.cpp" line="754"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditCom.cpp" line="989"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditCom.cpp" line="997"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="69"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="83"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="125"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="144"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="272"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="286"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="309"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="328"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="569"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="2057"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3540"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3556"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3570"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3586"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3602"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3616"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3632"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3648"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3667"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3687"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3834"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditLad.cpp" line="3933"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditNetwork.cpp" line="1121"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditStl.cpp" line="46"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditStl.cpp" line="53"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditStl.cpp" line="88"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditStl.cpp" line="95"/>
        <location filename="GuttaLad/Algorithm/GuttaEnvironment.cpp" line="441"/>
        <location filename="GuttaLad/Algorithm/GuttaEnvironment.cpp" line="449"/>
        <location filename="GuttaLad/Algorithm/GuttaEnvironment.cpp" line="466"/>
        <location filename="GuttaLad/Algorithm/GuttaEnvironment.cpp" line="474"/>
        <location filename="GuttaLad/Algorithm/GuttaEnvironment.cpp" line="491"/>
        <location filename="GuttaLad/Algorithm/GuttaEnvironment.cpp" line="499"/>
        <location filename="GuttaLad/Algorithm/GuttaEnvironment.cpp" line="516"/>
        <location filename="GuttaLad/Algorithm/GuttaEnvironment.cpp" line="524"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="598"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="605"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="618"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="621"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="624"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="658"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="661"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="687"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="699"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="702"/>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="738"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryAddressManager.cpp" line="103"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryAddressManager.cpp" line="114"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="157"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="173"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="189"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="219"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="249"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="279"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="309"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="375"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="382"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="411"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="418"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="461"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="475"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="498"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="517"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryManager.cpp" line="33"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryManager.cpp" line="55"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryManager.cpp" line="66"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryManager.cpp" line="77"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryManager.cpp" line="128"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilize.h" line="135"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilize.h" line="144"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilize.h" line="149"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilize.h" line="173"/>
        <source>$LogicError</source>
        <translation>Logic Error</translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataSet.h" line="306"/>
        <source>$DataSetInit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataSet.h" line="307"/>
        <source>$AttribNameNotExist:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="322"/>
        <source>$InstructionTypeNotCoreSystem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="351"/>
        <source>$InstructionTypeNotFirmwareModule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="380"/>
        <source>$InstructionTypeNotUserModule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="427"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="440"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="482"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="490"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="498"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="506"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="514"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="523"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="531"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="539"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="547"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="555"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="563"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="572"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="580"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="588"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="596"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="604"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="612"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="627"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="641"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="651"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="664"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="678"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="688"/>
        <source>$UpdateInstructionManager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="428"/>
        <source>$SlotValue&gt;=4096:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="441"/>
        <source>$SlotValueOverlapped:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="483"/>
        <source>$MissingUniqueMid:AND</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="491"/>
        <source>$MissingUniqueMid:OR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="499"/>
        <source>$MissingUniqueMid:LPS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="507"/>
        <source>$MissingUniqueMid:LRD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="515"/>
        <source>$MissingUniqueMid:LPP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="524"/>
        <source>$MissingUniqueStl:Ld</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="532"/>
        <source>$MissingUniqueStl:Ldi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="540"/>
        <source>$MissingUniqueStl:Ldp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="548"/>
        <source>$MissingUniqueStl:Ldf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="556"/>
        <source>$MissingUniqueStl:Inv</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="564"/>
        <source>$MissingUniqueStl:Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="573"/>
        <source>$MissingUniqueLad:Ld</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="581"/>
        <source>$MissingUniqueLad:Ldi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="589"/>
        <source>$MissingUniqueLad:Ldp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="597"/>
        <source>$MissingUniqueLad:Ldf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="605"/>
        <source>$MissingUniqueLad:Inv</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="613"/>
        <source>$MissingUniqueLad:Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="628"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="642"/>
        <source>$ConvertSTM:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="652"/>
        <source>$ConvertSTM:Left!=Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="665"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="679"/>
        <source>$ConvertLTM:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaInstructionManagerPartial.cpp" line="689"/>
        <source>$ConvertLTM:Left!=Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemConfiguration.cpp" line="51"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemConfiguration.cpp" line="57"/>
        <source>$CreateContent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemConfiguration.cpp" line="52"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemConfiguration.cpp" line="58"/>
        <source>$ClassPath:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="138"/>
        <source>$LoadProgramBlock:CoreSystemInvalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1035"/>
        <source>$SetProgramBlockSymbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1041"/>
        <source>$SetProgramBlockAddress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1047"/>
        <source>$SetProgramBlockComment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1088"/>
        <source>$InsertProgramBlockUnit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1117"/>
        <source>$RemoveProgramBlockUnit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1133"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1137"/>
        <source>$InsertRelativeVariableItem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1162"/>
        <source>$RemoveRelativeVariableItem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1194"/>
        <source>$MoveUpRelativeVariableItem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1219"/>
        <source>$MoveDownRelativeVariableItem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1414"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1440"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1534"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1597"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="1623"/>
        <source>$ModifyRelativeVariableItem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2494"/>
        <source>$ModifyNetworkComment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2525"/>
        <source>$ModifyNetwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2647"/>
        <source>$AnalyzeNetwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2722"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="2804"/>
        <source>$EditNetworkPaste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3009"/>
        <source>$InsertNetwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3059"/>
        <source>$InsertNetworkBelow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3102"/>
        <source>$RemoveNetwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3265"/>
        <source>$NetworkReplaceOperand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3289"/>
        <source>$NetworkLadCut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3372"/>
        <source>$NetworkLadPaste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3417"/>
        <source>$NetworkLadMove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3462"/>
        <source>$NetworkLadErase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3523"/>
        <source>$NetworkLadSetHorzElement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3568"/>
        <source>$NetworkLadRemoveRow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3613"/>
        <source>$NetworkLadInsertRow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3658"/>
        <source>$NetworkLadRemoveCol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaProgramBlock.cpp" line="3703"/>
        <source>$NetworkLadInsertCol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/GuttaGlobal.cpp" line="68"/>
        <source>$GlobalInitialize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/GuttaGlobal.cpp" line="68"/>
        <source>$NoTargetExist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryAddressManager.cpp" line="201"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryCoreSystem.cpp" line="183"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="561"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryTarget.cpp" line="388"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="23"/>
        <source>$AttributeSizeError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryAddressManager.cpp" line="202"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryCoreSystem.cpp" line="184"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="562"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryTarget.cpp" line="389"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="24"/>
        <source>$ValueError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryAddressManager.cpp" line="203"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryCoreSystem.cpp" line="185"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="563"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryTarget.cpp" line="390"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="25"/>
        <source>$AttributeError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryAddressManager.cpp" line="204"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryCoreSystem.cpp" line="186"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="564"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryTarget.cpp" line="391"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="26"/>
        <source>$NameError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryAddressManager.cpp" line="205"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryCoreSystem.cpp" line="187"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="565"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryTarget.cpp" line="392"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="27"/>
        <source>$StatusError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/Application/GuttaLibraryApplicationUnit.cpp" line="29"/>
        <source>$LoadLibraryApplication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/Application/GuttaLibraryApplicationUnit.cpp" line="30"/>
        <location filename="GuttaLad/Algorithm/Library/Configuration/GuttaLibraryConfigurationUnit.cpp" line="30"/>
        <location filename="GuttaLad/Algorithm/Library/Configuration/GuttaLibraryConfigurationUnit.cpp" line="35"/>
        <location filename="GuttaLad/Algorithm/Library/Configuration/GuttaLibraryConfigurationUnit.cpp" line="41"/>
        <location filename="GuttaLad/Algorithm/Library/Configuration/GuttaLibraryConfigurationUnit.cpp" line="69"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryAddressManager.cpp" line="480"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryCoreSystem.cpp" line="576"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="1068"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibrarySystemSymbols.cpp" line="26"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryTarget.cpp" line="730"/>
        <location filename="GuttaLad/Algorithm/Library/Link/GuttaLibraryLinkUnit.cpp" line="31"/>
        <location filename="GuttaLad/Algorithm/Library/Link/GuttaLibraryLinkUnit.cpp" line="36"/>
        <location filename="GuttaLad/Algorithm/Library/Link/GuttaLibraryLinkUnit.cpp" line="42"/>
        <location filename="GuttaLad/Algorithm/Library/Link/GuttaLibraryLinkUnit.cpp" line="65"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="141"/>
        <source>$FileName:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/Configuration/GuttaLibraryConfigurationUnit.cpp" line="29"/>
        <location filename="GuttaLad/Algorithm/Library/Configuration/GuttaLibraryConfigurationUnit.cpp" line="34"/>
        <location filename="GuttaLad/Algorithm/Library/Configuration/GuttaLibraryConfigurationUnit.cpp" line="40"/>
        <location filename="GuttaLad/Algorithm/Library/Configuration/GuttaLibraryConfigurationUnit.cpp" line="68"/>
        <source>$LoadLibraryConfiguration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryCoreSystem.cpp" line="575"/>
        <source>$LoadLibraryCoreSystem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryImportVector.cpp" line="44"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryImportVector.cpp" line="61"/>
        <source>$ClassTypeError:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryInstructionManager.cpp" line="1067"/>
        <source>$LoadLibraryInstructionManagerUnit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibrarySystemSymbols.cpp" line="25"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryTarget.cpp" line="729"/>
        <source>$LoadLibraryTarget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/Link/GuttaLibraryLinkUnit.cpp" line="30"/>
        <location filename="GuttaLad/Algorithm/Library/Link/GuttaLibraryLinkUnit.cpp" line="35"/>
        <location filename="GuttaLad/Algorithm/Library/Link/GuttaLibraryLinkUnit.cpp" line="41"/>
        <location filename="GuttaLad/Algorithm/Library/Link/GuttaLibraryLinkUnit.cpp" line="64"/>
        <source>$LoadLibraryLink</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeMessage.cpp" line="163"/>
        <location filename="GuttaLad/Dialog/InputTextDlg.cpp" line="58"/>
        <location filename="GuttaLad/Dialog/TC6BuildConfigDlg.cpp" line="87"/>
        <location filename="GuttaLad/Dialog/TC6EditLadInputDlg.cpp" line="315"/>
        <location filename="GuttaLad/Dialog/TC6EditLadInstructionDlg.cpp" line="358"/>
        <location filename="GuttaLad/Dialog/TC6EditLadOperandDlg.cpp" line="333"/>
        <location filename="GuttaLad/Dialog/TC6FunctionBlockPropertyDlg.cpp" line="48"/>
        <location filename="GuttaLad/Dialog/TC6ModulePropertyDlg.cpp" line="48"/>
        <location filename="GuttaLad/Dialog/TC6NetworkPropertyDlg.cpp" line="50"/>
        <location filename="GuttaLad/Dialog/TC6SubroutinePropertyDlg.cpp" line="60"/>
        <source>$OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeMessage.cpp" line="170"/>
        <location filename="GuttaLad/Dialog/InputTextDlg.cpp" line="59"/>
        <location filename="GuttaLad/Dialog/TC6BuildConfigDlg.cpp" line="88"/>
        <location filename="GuttaLad/Dialog/TC6EditLadInputDlg.cpp" line="316"/>
        <location filename="GuttaLad/Dialog/TC6EditLadInstructionDlg.cpp" line="359"/>
        <location filename="GuttaLad/Dialog/TC6EditLadOperandDlg.cpp" line="334"/>
        <location filename="GuttaLad/Dialog/TC6FunctionBlockPropertyDlg.cpp" line="49"/>
        <location filename="GuttaLad/Dialog/TC6ModulePropertyDlg.cpp" line="49"/>
        <location filename="GuttaLad/Dialog/TC6NetworkPropertyDlg.cpp" line="51"/>
        <location filename="GuttaLad/Dialog/TC6SubroutinePropertyDlg.cpp" line="61"/>
        <source>$Cancel</source>
        <oldsource>Cancel</oldsource>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeMessage.cpp" line="149"/>
        <source>$Yes</source>
        <translation>Yes</translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeMessage.cpp" line="156"/>
        <source>$No</source>
        <translation>NO</translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="91"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="104"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="137"/>
        <source>$XmlStreamReaderError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="36"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="49"/>
        <source>$StreamLoadFileError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="534"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="37"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="69"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="92"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlWriter.cpp" line="196"/>
        <source>$OpenFile: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="50"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="105"/>
        <source>$EmptyFile: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="68"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="73"/>
        <source>$StreamSaveFileError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="116"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="121"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="92"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="96"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="99"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="122"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="126"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="129"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="152"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="156"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="159"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="182"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="186"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="189"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="212"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="216"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="219"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="242"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="246"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="249"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="272"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="276"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="279"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="302"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="306"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="339"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="345"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="350"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.h" line="76"/>
        <source>$StreamParseError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="145"/>
        <source>$Row:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="146"/>
        <source>$Column:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlReader.cpp" line="150"/>
        <source>$Error:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="294"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="417"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="560"/>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryTarget.cpp" line="99"/>
        <source>$LinkConfigurationNotExist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="298"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="421"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="566"/>
        <source>$LinkNotValid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="299"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="303"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="422"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="426"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="567"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="573"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="121"/>
        <source>$Path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="302"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="425"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="572"/>
        <source>$SetLinkParameterError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="304"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="427"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="574"/>
        <source>$Parameter:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="309"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="432"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="581"/>
        <source>$OpenBus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="316"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="439"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="587"/>
        <source>$LoginPassword:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="317"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="375"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="440"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="501"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="588"/>
        <source>$OperationCanceled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="321"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="444"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="592"/>
        <source>$Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="335"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="456"/>
        <source>$ActivateUpload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="345"/>
        <source>$Uplaoding:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="366"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="487"/>
        <source>$Index:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="367"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="488"/>
        <source>$Start:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="368"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="489"/>
        <source>$Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="372"/>
        <source>$UploadFile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="390"/>
        <source>$CompleteUpload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="399"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="525"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="614"/>
        <source>$LogOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="468"/>
        <source>$Downloading:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="496"/>
        <source>$DownloadFile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="516"/>
        <source>$CompleteDownload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="639"/>
        <source>$MonitorOFF</source>
        <translation type="unfinished">Monitor &amp;OFF</translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="659"/>
        <source>$SetVariableFailed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="673"/>
        <source>$GetPLCStateFiled:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="687"/>
        <source>$StartPLCFiled:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="701"/>
        <source>$StopPLCFiled:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="852"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="947"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="948"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="949"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="950"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="991"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="992"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="1033"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="1074"/>
        <source>$Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="533"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="539"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlWriter.cpp" line="113"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlWriter.cpp" line="149"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlWriter.cpp" line="153"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlWriter.cpp" line="162"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlWriter.cpp" line="195"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlWriter.cpp" line="202"/>
        <source>$XmlStreamWriterError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaOnline.cpp" line="540"/>
        <location filename="GuttaLad/Algorithm/Stream/GuttaStreamV11W.cpp" line="74"/>
        <location filename="GuttaLad/Algorithm/Utilize/GuttaUtilizeXmlWriter.cpp" line="203"/>
        <source>WriteFile: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/SystemConfigDlg.cpp" line="29"/>
        <location filename="GuttaLad/Dialog/SystemConfigDlg.cpp" line="35"/>
        <location filename="GuttaLad/Dialog/SystemConfigDlg.cpp" line="45"/>
        <location filename="GuttaLad/Dialog/SystemConfigDlg.cpp" line="161"/>
        <source>$IndexNotExist:</source>
        <translation type="unfinished">Index Not Exist:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/SystemConfigDlg.cpp" line="62"/>
        <source>$LoadLibraryError:</source>
        <translation type="unfinished">Load Library Error:</translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/SystemConfigDlg.cpp" line="51"/>
        <location filename="GuttaLad/Dialog/SystemConfigDlg.cpp" line="167"/>
        <source>$GetUserParamError:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaRecorder.cpp" line="65"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaRecorder.cpp" line="82"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaRecorder.cpp" line="91"/>
        <source>$RecordingNestingCountError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaRecorder.h" line="84"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaRecorder.h" line="94"/>
        <source>$ActionCast:ContentIsEmpty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaRecorder.h" line="87"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaRecorder.h" line="97"/>
        <source>$ActionCast:TypeMismatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="56"/>
        <source>$InitError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="56"/>
        <source>$GDIAlreadyInitialized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="99"/>
        <source>$DeInitError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/GuttaGdi.cpp" line="99"/>
        <source>$GDINotInitialized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Library/GuttaLibraryAddressManager.cpp" line="479"/>
        <source>$LoadUnit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="116"/>
        <source>$FileVerError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="121"/>
        <source>$PlcTypeError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="430"/>
        <source>$ConvertStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="448"/>
        <source>$ConvertFinished, </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="449"/>
        <source> $Warning(s), </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaDataProject.cpp" line="450"/>
        <source> $Error(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="540"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="558"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="562"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="225"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="255"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="956"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="986"/>
        <source>$[LTM]AnalyzeInternalError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1059"/>
        <source>$[MTS]OutputPowerNotMatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1067"/>
        <source>$[MTS]OutputOrderNotMatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1099"/>
        <source>$[MTS]ContextPowerNotMatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1115"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1120"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1136"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1141"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1224"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1230"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1245"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1251"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1266"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1272"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1287"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1293"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1309"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1315"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1329"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1336"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1346"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1353"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1356"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1439"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1449"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="437"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="444"/>
        <source>$[MTS]AnalyzeInternalError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1148"/>
        <source>$[MTS]TherePendingOutputWhenFinished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1227"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1248"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1269"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1290"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1312"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1339"/>
        <source>$[MTS]DataStackOverflowError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1370"/>
        <source>$[MTS]OuputPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1377"/>
        <source>$[MTS]OutputSequenceEndPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1383"/>
        <source>$[MTS]OutputLabelPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1474"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1489"/>
        <source>$[MTS]InputSequenceBeginPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1644"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1671"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1892"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1981"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1997"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2007"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2035"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="3058"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="501"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="533"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="536"/>
        <source>$[STM]AnalyzeInternalError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1744"/>
        <source>$[STM]DirectlyUseLpsError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1747"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1775"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1798"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1819"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1840"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1875"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1937"/>
        <source>$[STM]DataStackOverflowError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1750"/>
        <source>$[STM]InstructionAndError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1772"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1778"/>
        <source>$[STM]InstructionOrError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1795"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1801"/>
        <source>$[STM]InstructionLpsError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1816"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1822"/>
        <source>$[STM]InstructionLrdError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1837"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1843"/>
        <source>$[STM]InstructionLppError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1862"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1872"/>
        <source>$[STM]InputPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1924"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1934"/>
        <source>$[STM]OutputPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1963"/>
        <source>$[STM]OutputSequenceEndPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="1976"/>
        <source>$[STM]OutputLabelPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2271"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2290"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2317"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2330"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2333"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2340"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2532"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2535"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2640"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2643"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2685"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2700"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2704"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2723"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2738"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2742"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2781"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2784"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2812"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2815"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2853"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2857"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2865"/>
        <source>$[MTL]AnalyzeInternalError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2274"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2293"/>
        <source>$[MTL]ElementConversionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2368"/>
        <source>$[MTL]ContextPowerNotMatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="2371"/>
        <source>$[MTL]OutputPowerNotMatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="3034"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="466"/>
        <source>$[STM]ElementConversionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeBasic.cpp" line="3054"/>
        <source>$[STM]NeedSequenceEndBefore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="43"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="50"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="60"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="74"/>
        <source>$[ETL]ElementError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="100"/>
        <source>$[ETL]AnalyzeInternalError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="126"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="135"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="146"/>
        <source>$[LTE]]ElementError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="165"/>
        <source>$[LTE]]AnalyzeInternalError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="186"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="199"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="917"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="930"/>
        <source>$[LTM]ElementConversionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="206"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="937"/>
        <source>$[LTM]NoOutputElementError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="215"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="946"/>
        <source>$[LTM]InputElementError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="219"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="950"/>
        <source>$[LTM]InputSequenceBeginElementError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="222"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="953"/>
        <source>$[LTM]InputElementConversionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="235"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="966"/>
        <source>$[LTM]OutputElementError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="237"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="968"/>
        <source>$[LTM]OutputElementDirectlyOnBus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="241"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="972"/>
        <source>$[LTM]OutputSequenceEndElementError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="243"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="974"/>
        <source>$[LTM]OutputSequenceEndElementDirectlyOnBus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="247"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="978"/>
        <source>$[LTM]OutputLabelElementError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="249"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="980"/>
        <source>$[LTM]OutputLabelElementNotDirectlyOnBus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="252"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="983"/>
        <source>$[LTM]OutputElementConversionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="271"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="1002"/>
        <source>$[LTM]MultiInputElementPowerflowError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="289"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="1020"/>
        <source>$[LTM]MultiOutputElementPowerflowError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="307"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="1038"/>
        <source>$[LTM]UselessInputElement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="332"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="1063"/>
        <source>$[LTM]SimplifyDiagramError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="385"/>
        <source>$[MTL]GetInputPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="394"/>
        <source>$[MTL]GetOutputPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="453"/>
        <source>$[MTS]ElementConversionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="560"/>
        <source>$[STM]InputSelfConnected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="576"/>
        <source>$[STM]OutputSelfConnected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="586"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="624"/>
        <source>$[STM]LppOrLrdPositionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="600"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="608"/>
        <source>$[STM]ContextSelfConnected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="647"/>
        <source>$[STE]ElementError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="681"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="688"/>
        <source>$[ETS]ElementError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="749"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="796"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="801"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="829"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="849"/>
        <location filename="GuttaLad/Algorithm/Analyze/GuttaAnalyzeConvert.cpp" line="852"/>
        <source>$AnalyzeInternalError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditCom.cpp" line="1336"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditNetwork.cpp" line="389"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditNetwork.cpp" line="814"/>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditNetwork.cpp" line="816"/>
        <source>$Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditNetwork.cpp" line="27"/>
        <source>$UnitComment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditNetwork.cpp" line="399"/>
        <source>$Subrountine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditNetwork.cpp" line="408"/>
        <source>$Event</source>
        <translation type="unfinished">Event</translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditNetwork.cpp" line="414"/>
        <source>$FunctionBlock</source>
        <translation type="unfinished">Function Block</translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditNetwork.cpp" line="438"/>
        <source>$NetworkTitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Edit/GuttaEditNetwork.cpp" line="483"/>
        <source>$NetworkComment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="575"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="591"/>
        <source>$[LDTM]ConnectionPointInEmpty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="578"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="594"/>
        <source>$[LDTM]ConnectionEmpty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="598"/>
        <source>$[LDTM]OutVariableRefLocalIdError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="608"/>
        <source>$[LDTM]OutVariableFormalParameterNotExist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="618"/>
        <source>$[LDTM]LeftPowerRailMultyConnectionPointOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="627"/>
        <source>$[LDTM]ContactMultyConnectionPointOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="648"/>
        <source>$[LDTM]BlockMultyConnectionPointOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="663"/>
        <source>$[LDTM]ContactMultyConnectionPointIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="666"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="684"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="704"/>
        <source>$[LDTM]NoConnectionOnConnectionPointIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="673"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="691"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="714"/>
        <source>$[LDTM]ConnectionPointOutNotExist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="681"/>
        <source>$[LDTM]CoilMultyConnectionPointIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="701"/>
        <source>$[LDTM]InputVariableMultyConnectionPointIn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="758"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="803"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="862"/>
        <source>$[LDTM]ElementConversionError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="1094"/>
        <source>$[LDTM]LocalIdOutOfRange</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Analyze.cpp" line="1100"/>
        <source>$[LDTM]LocalIdDuplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="1994"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2068"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2114"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2154"/>
        <source>$UnknownError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2071"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2117"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2202"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2210"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2213"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2219"/>
        <source>$ExchError</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="1998"/>
        <source>$CMD:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="1997"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2002"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2076"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2122"/>
        <source>$ExchError:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2157"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2161"/>
        <source>$ReadError:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2158"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2162"/>
        <source>$GetDebugInfo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2202"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2210"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2213"/>
        <source>$UncompressData</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Exch.cpp" line="2219"/>
        <source>$UncompressData:FileSize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="124"/>
        <source>$Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="126"/>
        <source>$InOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="128"/>
        <source>$Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="132"/>
        <source>$Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="134"/>
        <source>[$Event]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="137"/>
        <source>$Level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="139"/>
        <source>$Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="141"/>
        <source>$Critical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="145"/>
        <source>$Assembly:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="146"/>
        <source>$Namespace:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="147"/>
        <source>$Owner:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaSystemSymbols.cpp" line="165"/>
        <source>$LoadSystemSymbols:CoreSystemInvalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Xml.cpp" line="655"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Xml.cpp" line="749"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Xml.cpp" line="782"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Xml.cpp" line="825"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Xml.cpp" line="834"/>
        <source>$ReadTC6XmlProject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Xml.cpp" line="655"/>
        <source>$ProjectConfigurationNotExist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Xml.cpp" line="749"/>
        <source>$EditInsertUnitFailed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Xml.cpp" line="782"/>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Xml.cpp" line="834"/>
        <source>$BodyTypeError:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/TC6/GuttaTC6Xml.cpp" line="827"/>
        <source>$BodyConvertError:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Dialog/FindAndReplaceDlg.cpp" line="91"/>
        <source>$Replaced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="1253"/>
        <source>$Undo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainFrm.cpp" line="1334"/>
        <source>$Redo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="139"/>
        <source>$LoadGlobalVariable:CoreSystemInvalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="673"/>
        <source>$InsertGlobalVariableUnit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="693"/>
        <source>$RemoveGlobalVariableUnit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="709"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="713"/>
        <source>$InsertGlobalVariableItem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="738"/>
        <source>$RemoveGlobalVariableItem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="770"/>
        <source>$MoveUpGlobalVariableItem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="795"/>
        <source>$MoveDownGlobalVariableItem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="990"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1016"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1103"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1161"/>
        <location filename="GuttaLad/Algorithm/Data/GuttaGlobalVariable.cpp" line="1187"/>
        <source>$ModifyGlobalVariableItem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="79"/>
        <source>$LoadStatusChart:CoreSystemInvalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="396"/>
        <source>$InsertStatusChartUnit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="416"/>
        <source>$RemoveStatusChartUnit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="431"/>
        <source>$StatusChartMoveItemUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="453"/>
        <source>$StatusChartMoveItemDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="GuttaLad/Algorithm/Data/GuttaStatusChart.cpp" line="601"/>
        <source>$StatusChartSetItemVariable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
